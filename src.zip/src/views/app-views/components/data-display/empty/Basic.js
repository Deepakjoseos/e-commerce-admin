import React, { Component } from "react";
import { Empty } from "antd";

export class Basic extends Component {
  render() {
    return <Empty />;
  }
}

export default Basic;
