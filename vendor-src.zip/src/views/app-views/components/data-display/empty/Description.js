import React, { Component } from "react";
import { Empty } from "antd";

export class Description extends Component {
  render() {
    return <Empty description={false} />;
  }
}

export default Description;
